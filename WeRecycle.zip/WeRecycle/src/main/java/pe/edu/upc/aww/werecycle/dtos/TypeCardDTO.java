package pe.edu.upc.aww.werecycle.dtos;

public class TypeCardDTO {

    private int idTypeCard;

    private String cardType;

    public int getIdTypeCard() {
        return idTypeCard;
    }

    public void setIdTypeCard(int idTypeCard) {
        this.idTypeCard = idTypeCard;
    }

    public String getCardType() {
        return cardType;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType;
    }
}
