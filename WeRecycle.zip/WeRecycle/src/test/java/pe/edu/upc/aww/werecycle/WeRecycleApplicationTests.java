package pe.edu.upc.aww.werecycle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WeRecycleApplicationTests {

    @Test
    void contextLoads() {
    }

}
